SET DEFINE OFF;
Insert into R_SETTINGS
   (SETTING_ID, CODE, NAME, HIDDEN_YN)
 Values
   (8, 'EXPORT_MULTILANG_YN', 'Export APEX applications and components as multi language? Values are Y/N', 'N');
Insert into R_SETTINGS
   (SETTING_ID, CODE, NAME, HIDDEN_YN)
 Values
   (9, 'SEED_PUBLISH_YN', 'Seed and publish miltilang apps before patch confirmation? Values are Y/N', 'N');


INSERT INTO project_settings (project_id, setting_id, value_vc2)
SELECT
    p.project_id,
    v.setting_id,
    'N' as value_no
FROM 
    projects p
    CROSS JOIN (SELECT setting_id FROM r_settings WHERE setting_id in (8,9) ) v
;

COMMIT;


CREATE OR REPLACE SYNONYM PKG_DOME_INTERFACE FOR PKG_INTERFACE
/



V_PATCH_OBJ_SRC_SCRIPTS
V_PATCHES


PKG_OBJECTS
PKG_DECLARATIONS
PKG_UTILS
PKG_DOME_UTILS


