SET DEFINE OFF;
--
-- PKG_DECLARATIONS  (Package) 
--
CREATE OR REPLACE PACKAGE pkg_declarations IS

SUBTYPE yes_no IS varchar2(1);


FUNCTION f_display_yn (
    p_value varchar2
) RETURN varchar2;


END pkg_declarations;
/


--
-- PKG_DOME_UTILS  (Package) 
--
CREATE OR REPLACE PACKAGE PKG_DOME_UTILS AS 


--object scripts
FUNCTION f_get_database_object_script(
    p_name varchar2,
    p_type varchar2,
    p_grants_yn varchar2 default 'N'
) RETURN clob;


FUNCTION f_get_app_component_script(
    p_app_no number,
    p_id number,
    p_type varchar2
) RETURN clob;


FUNCTION f_get_app_script(
    p_app_no number
) RETURN clob;


--object lists
FUNCTION f_get_objects_list(
    p_object_type varchar2  --values: ORDS
) RETURN PKG_DOME_INTERFACE.t_objects;

--lock page
FUNCTION f_page_locked_yn(
    p_app_number number,
    p_page_number number
) RETURN varchar2;


END PKG_DOME_UTILS;
/


--
-- PKG_OBJECTS  (Package) 
--
CREATE OR REPLACE PACKAGE PKG_OBJECTS AS 


CURSOR c_data(p_object_id objects.object_id%TYPE) IS
SELECT
    o.filename,
    coalesce(
        v_dbo.db_schema_name,
        v_apc.app_schema_name,
        v_app.schema_name
    ) as db_schema,
    coalesce(
        v_apc.application_number,
        v_app.application_number
    ) as application_number,
    ot.target_folder,
    ot.source_folder
FROM
    objects o
    JOIN object_types ot ON o.object_type_id = ot.object_type_id
    LEFT JOIN v_database_objects v_dbo ON o.object_id = v_dbo.db_object_id
    LEFT JOIN v_app_components v_apc ON o.object_id = v_apc.app_component_id
    LEFT JOIN v_applications v_app ON o.object_id = v_app.application_id
WHERE o.object_id = p_object_id
;


FUNCTION f_get_object_id(
    p_parent_object_type varchar2,
    p_parent_object varchar2,
    p_object_type varchar2,
    p_object_name varchar2
) RETURN objects.object_id%TYPE
;


--database object file names
FUNCTION f_db_object_filename(
    p_name varchar2,
    p_type varchar2
) RETURN objects.filename%TYPE;

--source filename (with folder and chema name and app ID replace)
FUNCTION f_source_filename(
    p_object_id objects.object_id%TYPE
) RETURN varchar2;



--refresh object register
PROCEDURE p_refresh_database_objects(
    p_db_schemas objects.name%TYPE,  --database schemas
    p_object_types object_types.code%TYPE
);

PROCEDURE p_refresh_app_comp(
    p_app_ids varchar2  --application IDs (input is checkbox and string is : separated)
);

FUNCTION f_merge_app_component (
    p_comp_id number,
    p_app_id number,
    p_type_code varchar2,
    p_comp_name varchar2
) RETURN objects.object_id%TYPE;



--create object
FUNCTION f_create_db_object(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2
) RETURN objects.object_id%TYPE;


FUNCTION f_exclude_from_record_yn(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2,
    p_exclusion_type varchar2  --P (patch) or R (register)
) RETURN varchar2;



--object scripts
FUNCTION f_get_database_object_script(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2,
    p_grants_yn varchar2 default 'N'
) RETURN clob;

FUNCTION f_get_app_component_script(
    p_app_no number,
    p_component_id number,
    p_type varchar2,
    p_multilang_yn varchar2 default 'N'
) RETURN clob;

FUNCTION f_get_app_script(
    p_app_no number,
    p_multilang_yn varchar2 default 'N'
) RETURN clob;

FUNCTION f_default_db_schema 
RETURN v_database_schemas.schema_name%TYPE;



--locks
PROCEDURE p_lock_object(
    p_object_id objects.object_id%TYPE,
    p_lock_type objects.lock_type%TYPE,
    p_comment objects.lock_comment%TYPE
);

PROCEDURE p_unlock_object(
    p_object_id objects.object_id%TYPE
);

FUNCTION f_is_object_locked_yn(
    p_object_id objects.object_id%TYPE,
    p_user_id app_users.app_user_id%TYPE
) RETURN varchar2;


FUNCTION f_who_locked_object(
    p_object_id objects.object_id%TYPE
) RETURN app_users.app_user_id%TYPE;


FUNCTION f_page_locked_in_apex_yn(
    p_object_id objects.object_id%TYPE
) RETURN varchar2;

FUNCTION f_multilang_app_yn (
    p_application_id number
) RETURN varchar2;


END PKG_OBJECTS;
/


--
-- PKG_UTILS  (Package) 
--
CREATE OR REPLACE PACKAGE PKG_UTILS AS 

FUNCTION f_clob_to_blob(
    c clob,
    plEncoding IN NUMBER default 0
) RETURN blob;

FUNCTION f_blob_to_clob(
    blob_in IN blob,
    plEncoding IN NUMBER default 0
) RETURN clob;



PROCEDURE p_download_document(
    p_doc IN OUT blob,
    p_file_name varchar2,
    p_disposition varchar2 default 'attachment'  --values "attachment" and "inline"
);

PROCEDURE p_download_document(
    p_text IN OUT clob,
    p_file_name varchar2,
    p_disposition varchar2 default 'attachment'  --values "attachment" and "inline"
);

PROCEDURE p_vc_arr2_to_apex_coll(
    p_app_coll wwv_flow_global.vc_arr2,
    p_apex_coll_name varchar2,
    p_n001_yn varchar2 default 'N'
);


PROCEDURE p_seed_and_publish (
    p_app_no number,
    p_seed_yn varchar2 default 'Y',
    p_publish_yn varchar2 default 'Y',
    p_commit_yn varchar2 default 'N'
);


END PKG_UTILS;
/

SET DEFINE OFF;
--
-- PKG_DECLARATIONS  (Package Body) 
--
CREATE OR REPLACE PACKAGE BODY pkg_declarations IS

FUNCTION f_display_yn (
    p_value varchar2
) RETURN varchar2 IS
BEGIN
    RETURN
        CASE p_value
            WHEN 'Y' THEN 'Yes'
            ELSE 'No'
        END
    ;
END f_display_yn;


END pkg_declarations;
/


--
-- PKG_DOME_UTILS  (Package Body) 
--
CREATE OR REPLACE PACKAGE BODY PKG_DOME_UTILS AS

FUNCTION f_db_object_exists_yn(
    p_name varchar2,
    p_type varchar2
) RETURN varchar2 IS

    lcObjectExists varchar2(1);

BEGIN
    if p_type in ('DIRECTORY') then
        SELECT 'Y'
        INTO lcObjectExists
        FROM all_objects
        WHERE
            object_type = p_type
        AND object_name = p_name
        ;
    
    else
        SELECT 'Y'
        INTO lcObjectExists
        FROM user_objects
        WHERE
            object_type = p_type
        AND object_name = p_name
        ;
    
    end if;

    RETURN lcObjectExists;
    
EXCEPTION WHEN no_data_found THEN 
    RETURN 'N';
    
END f_db_object_exists_yn;




FUNCTION f_get_database_object_script(
    p_name varchar2,
    p_type varchar2,
    p_grants_yn varchar2 default 'N'
) RETURN clob AS

    lcScript clob;

    CURSOR c_grants IS
        SELECT 
            'GRANT ' || privilege || ' TO ' || grantee || ' ON ' || table_name || chr(10) || '/' || chr(10) as grant_script
        FROM user_tab_privs
        WHERE 
            type = p_type
        AND table_name = p_name
        AND owner = SYS_CONTEXT('USERENV', 'CURRENT_SCHEMA')
        ;

BEGIN
    if p_type = 'ORDS' then
        lcScript := ords_export.export_module(
            p_module_name => p_name
        );

    elsif p_type = 'DIRECTORY' then
        --TODO: fix script for directories
        RETURN null;
        
    else
        --if object doesn't exist (dropped or some other reason) just return empty script
        if f_db_object_exists_yn(p_name => p_name, p_type => p_type) = 'N' then
            RETURN null;
        end if;

        --used mostly for triggers to separate trigger ENABLE statement from trigger definition
        DBMS_METADATA.set_transform_param(DBMS_METADATA.session_transform, 'SQLTERMINATOR', true);
        
        --main object script
        lcScript := dbms_metadata.get_ddl(
            object_type => 
                CASE p_type 
                    WHEN 'PACKAGE' THEN 'PACKAGE_SPEC'
                    WHEN 'PACKAGE BODY' THEN 'PACKAGE_BODY'
                    ELSE p_type
                END, 
            name => p_name
        );
        
        if p_grants_yn = 'Y' and p_type in ('PACKAGE', 'VIEW', 'TABLE') then
            lcScript := lcScript || chr(10) || chr(10);
        
            FOR t IN c_grants LOOP
                lcScript := lcScript || t.grant_script;
            END LOOP;
        end if;
        
    end if;
    
    RETURN lcScript;
    
END f_get_database_object_script;



FUNCTION f_get_app_component_script(
    p_app_no number,
    p_id number,
    p_type varchar2
) RETURN clob AS

    lrFiles apex_t_export_files;
    lcFileName apex_application_static_files.file_name%TYPE;

BEGIN
    --get files
    if p_type <> 'STATIC_APP_FILE' then  --classic components
    
        lrFiles := apex_export.get_application(
            p_application_id => p_app_no,
            p_split => false,
            --p_with_ir_public_reports => true,
            p_with_translations => true,
            p_with_comments => true,
            p_components => apex_t_varchar2( p_type || ':' || p_id )
        );

        RETURN lrFiles(lrFiles.first).contents;
        
    else  --static application files

        --get splitted application scripts
        lrFiles := apex_export.get_application(
            p_application_id => p_app_no,
            p_split => true,
            p_with_translations => true,
            p_with_comments => true
        );

        --get file name
        SELECT 
            lower(
                replace( replace(file_name, '/', '_'), '.', '_') 
            )
        INTO lcFileName
        FROM apex_application_static_files
        WHERE application_file_id = p_id
        ;

        --loop through static app files and pick script for selected static application file
        FOR t IN 1 .. lrFiles.count LOOP

            if instr(lrFiles(t).name, lcFileName || '.sql') > 0 then
                RETURN 
                    lrFiles(t).contents ||  
                    chr(10) ||
                    'BEGIN' || chr(10) || 
                    '    COMMIT;' || chr(10) || 
                    'END;' || chr(10) || 
                    '/';
            end if;
             
        END LOOP;
        
        RAISE_APPLICATION_ERROR( -20001, 'Script for static app file ' || lcFileName || ' not found! Please contact administrator.');
        
    end if;
    
END f_get_app_component_script;


FUNCTION f_get_app_script(
    p_app_no number
) RETURN clob IS

    l_files apex_t_export_files;

BEGIN
    --get files
    l_files := apex_export.get_application(
        p_application_id => p_app_no,
        p_split => false,
        --p_with_ir_public_reports => true,
        p_with_translations => true,
        p_with_comments => true
    );

    RETURN l_files(l_files.first).contents;

END f_get_app_script;



FUNCTION f_get_objects_list(
    p_object_type varchar2  --values: ORDS
) RETURN PKG_DOME_INTERFACE.t_objects IS

    lrList PKG_DOME_INTERFACE.t_objects := PKG_DOME_INTERFACE.t_objects();

BEGIN
    if p_object_type = 'ORDS' then
        SELECT 
            name 
        BULK COLLECT INTO lrList
        FROM user_ords_modules;
    end if;

    RETURN lrList;
END f_get_objects_list;



FUNCTION f_page_locked_yn(
    p_app_number number,
    p_page_number number
) RETURN varchar2 IS

    lcYesNo varchar2(1);

BEGIN
    SELECT
        CASE 
            WHEN EXISTS 
                (
                SELECT 1 
                FROM apex_application_locked_pages ap
                WHERE
                    ap.application_id = p_app_number
                AND ap.page_id = p_page_number
                )
            THEN 'Y'
            ELSE 'N'
        END
    INTO lcYesNo
    FROM dual;

    RETURN lcYesNo;
END f_page_locked_yn;


PROCEDURE p_lock_page(
    p_user varchar2,
    p_application_number number,
    p_page_number number,
    p_comment varchar2
) IS
BEGIN
    --TODO
    
    /*
    --==============================================================================
    -- Locks or updates an existing page lock. The result is returned
    -- with the following JSON structure:
    --
    -- { isUserOwner: true,   // only emitted in case of true
    --   owner:   "<string>", // only emitted if isUserOwner = flase
    --   on:      "<string">,
    --   comment: "<string>"
    -- }
    --
    --==============================================================================
    procedure lock_page (
        p_application_id in number,
        p_page_id        in number,
        p_comment        in varchar2 );
    */

/*
PROCEDURE LOCK_PAGE (
    P_APPLICATION_ID IN NUMBER,
    P_PAGE_ID        IN NUMBER,
    P_COMMENT        IN VARCHAR2 )
IS
    L_LOCK T_PAGE_LOCK;
BEGIN
    WWV_FLOW_DEBUG.ENTER(
        'lock_page',
        'p_application_id', P_APPLICATION_ID,
        'p_page_id',        P_PAGE_ID,
        'p_comment',        P_COMMENT );

    WWV_FLOW_JSON.INITIALIZE_OUTPUT (
        P_HTTP_CACHE => FALSE );

    L_LOCK := GET_PAGE_LOCK_STATE (
                  P_APPLICATION_ID => P_APPLICATION_ID,
                  P_PAGE_ID        => P_PAGE_ID );

    
    
    
    
    IF L_LOCK.LOCKED_BY IS NULL THEN

        INSERT INTO WWV_FLOW_LOCK_PAGE (
            FLOW_ID,
            OBJECT_ID,
            LOCK_COMMENT,
            LOCKED_BY,
            LOCKED_ON )
        VALUES (
            P_APPLICATION_ID,
            P_PAGE_ID,
            P_COMMENT,
            WWV_FLOW.G_USER,
            SYSDATE );

    ELSIF L_LOCK.LOCKED_BY = WWV_FLOW.G_USER THEN

        UPDATE WWV_FLOW_LOCK_PAGE
           SET LOCK_COMMENT = P_COMMENT
         WHERE FLOW_ID           = P_APPLICATION_ID
           AND OBJECT_ID         = P_PAGE_ID
           AND SECURITY_GROUP_ID = WWV_FLOW_SECURITY.G_SECURITY_GROUP_ID;

    END IF;

    
    EMIT_PAGE_LOCK_STATE (
        P_APPLICATION_ID => P_APPLICATION_ID,
        P_PAGE_ID        => P_PAGE_ID,
        P_OBJECT_NAME    => NULL );

END LOCK_PAGE;
*/
    
    null;
    
    --WWV_FLOW_PROPERTY_DEV.lock_page
END p_lock_page;

PROCEDURE p_unlock_page(
    p_user varchar2,
    p_application_number number,
    p_page_number number
) IS
BEGIN
    --TODO

/*
--==============================================================================
-- Unlocks the current page lock. The result is returned
-- with the following JSON structure:
--
-- { status: "OK" / "FAILED",
--   reason: "<error>"
-- }
--
--==============================================================================
procedure unlock_page (
    p_application_id in number,
    p_page_id        in number );

*/
    null;
    --WWV_FLOW_PROPERTY_DEV.unlock_page
END p_unlock_page;


END PKG_DOME_UTILS;
/


--
-- PKG_OBJECTS  (Package Body) 
--
CREATE OR REPLACE PACKAGE BODY PKG_OBJECTS AS


CURSOR c_export_apps (
    p_app_no number,
    p_multilang_yn varchar2
) IS
    SELECT 
        to_number(p_app_no) as app_id,  --primary application -> always exported
        'N' as translated_app_yn
    FROM dual
    UNION ALL 
    SELECT  --translated applications -> if set on project level
        aatm.translated_application_id,
        'Y' as translated_app_yn
    FROM apex_application_trans_map aatm
    WHERE 
        aatm.primary_application_id = p_app_no
    AND p_multilang_yn = 'Y'
;


FUNCTION f_get_object_record(
    p_object_id objects.object_id%TYPE
) RETURN objects%ROWTYPE IS

    lrObject objects%ROWTYPE;

BEGIN
    SELECT *
    INTO lrObject
    FROM objects
    WHERE object_id = p_object_id;

    RETURN lrObject;
END f_get_object_record;



FUNCTION f_get_object_id(
    p_parent_object_type varchar2, --APPLICATION, DB_SCHEMA
    p_parent_object varchar2, --parent object marker - application number, schema name...
    p_object_type varchar2,
    p_object_name varchar2

) RETURN objects.object_id%TYPE IS

    lnID objects.object_id%TYPE;

BEGIN
    if p_parent_object_type = 'DB_SCHEMA' then
        SELECT v_dbo.db_object_id
        INTO lnID
        FROM 
            v_database_objects v_dbo
        WHERE
            nvl(v_dbo.db_schema_name, 'x') = nvl(p_parent_object, 'x')  --some objects are not on schema level... for example directory 
        AND v_dbo.db_object_name = p_object_name
        AND v_dbo.object_type_code = p_object_type
        ;
        
    elsif p_parent_object_type = 'APPLICATION' then
        SELECT v_apc.app_component_id 
        INTO lnID
        FROM
            v_app_components v_apc
        WHERE
            v_apc.application_number = p_parent_object
        AND v_apc.app_component_name = p_object_name
        AND v_apc.object_type_code = p_object_type
        ;
    
    end if;
    

    RETURN lnID;
    
EXCEPTION WHEN no_data_found THEN
    RETURN null;
    
END f_get_object_id;


FUNCTION f_db_object_filename(
    p_name varchar2,
    p_type varchar2
) RETURN objects.filename%TYPE IS
BEGIN
    RETURN
        lower(p_name) || (
            CASE p_type 
                WHEN 'PACKAGE' THEN '.pks' 
                WHEN 'PACKAGE BODY' THEN '.pkb' 
                ELSE '.sql' END
            )
    ;
END f_db_object_filename;

PROCEDURE p_refresh_database_objects(
    p_db_schemas objects.name%TYPE,  --database schemas
    p_object_types object_types.code%TYPE
) AS

    lrOrdsList pkg_interface.t_objects;

BEGIN
    --insert standard objects from DBA_OBJECTS view
    INSERT INTO objects (
        parent_object_id,
        object_type_id,
        name,
        filename
        )
    SELECT
        dbs.schema_id as db_schema_id,
        obt.object_type_id,
        upper(dbo.object_name) as object_name,
        pkg_objects.f_db_object_filename(
            p_name => dbo.object_name,
            p_type => dbo.object_type
        ) as filename
    FROM 
        dba_objects dbo
        JOIN v_database_schemas dbs ON dbo.owner = dbs.schema_name
        JOIN object_types obt ON dbo.object_type = obt.code
    WHERE
        dbo.owner in ( SELECT column_value FROM TABLE(apex_string.split(p_db_schemas, ':')) )
    AND dbo.object_type in ( SELECT column_value FROM TABLE(apex_string.split(p_object_types, ':')) )
    AND not exists --only new objects
        (
        SELECT 1
        FROM v_database_objects v_dbo 
        WHERE 
            dbo.owner = v_dbo.db_schema_name
        AND upper(dbo.object_name) = upper(v_dbo.db_object_name)
        AND dbo.object_type = v_dbo.object_type_code
        )
    ;
    
    --mark dropped objects as inactive
    UPDATE objects
    SET active_yn = 'N'
    WHERE object_id in 
    (
    SELECT v_dbo.db_object_id
    FROM v_database_objects v_dbo
    WHERE 
        v_dbo.object_type_code <> 'ORDS'
    AND v_dbo.db_schema_name in ( SELECT column_value FROM TABLE(apex_string.split(p_db_schemas, ':')) )
    AND v_dbo.object_type_code in ( SELECT column_value FROM TABLE(apex_string.split(p_object_types, ':')) )
    AND v_dbo.active_yn = 'Y'
    AND NOT EXISTS 
        (
        SELECT 1 
        FROM dba_objects dba_obj
        WHERE
            v_dbo.db_object_name = dba_obj.object_name
        AND v_dbo.object_type_code = dba_obj.object_type
        AND v_dbo.db_schema_name = dba_obj.owner
        )
    )
    ;
    
    
    --refresh ORDS (if selected)
    if instr(p_object_types, 'ORDS') > 0 then
        FOR t IN ( SELECT column_value as schema_name FROM TABLE(apex_string.split(p_db_schemas, ':')) ) LOOP
        
            EXECUTE IMMEDIATE 'BEGIN :1 := ' || t.schema_name || '.PKG_DOME_UTILS.f_get_objects_list(''ORDS''); END;'
            USING OUT lrOrdsList;
            
            --used FOR LOOP because INSERT INTO ... SELECT is throwing invalid datatype error???
            FOR p IN (
                SELECT
                    v_dbs.schema_id,
                    ot.object_type_id,
                    v_list.name as object_name,
                    lower(ot.code || '_' || v_list.name || '.sql') as filename
                FROM 
                    table( lrOrdsList ) v_list
                    JOIN v_database_schemas v_dbs ON v_dbs.schema_name = t.schema_name
                    JOIN object_types ot ON ot.code = 'ORDS'
                    LEFT JOIN v_database_objects v_dbo ON 
                            v_dbo.db_object_name = v_list.name
                        AND v_dbo.object_type_code = ot.code
                        AND v_dbo.db_schema_name = t.schema_name
                WHERE v_dbo.db_object_id is null  --only new objects
            ) LOOP
            
                INSERT INTO objects (
                    parent_object_id,
                    object_type_id,
                    name,
                    filename
                ) VALUES (
                    p.schema_id,
                    p.object_type_id,
                    p.object_name,
                    p.filename
                );
            
            END LOOP;
            
        END LOOP;
        
    end if;
    
    
END p_refresh_database_objects;


PROCEDURE p_refresh_app_comp(
    p_app_ids varchar2  --application IDs
) AS
BEGIN
    --merge into for all selected applications
    MERGE INTO objects obj
    USING (
        --app components
        SELECT 
            vju.id, 
            vju.name, 
            ot.object_type_id,
            v_app.application_id,
            ob.object_id,
            lower(ot.code) || '_' || v_app.application_number || '_' || vju.id || '.sql' as filename
        FROM 
            apex_appl_export_comps vju
            JOIN object_types ot ON vju.type_name = ot.code AND ot.object_location = 'APP'
            JOIN v_applications v_app ON vju.application_id = v_app.application_number
            LEFT JOIN objects ob ON 
                    ob.parent_object_id = v_app.application_id
                AND ob.object_type_id = ot.object_type_id
                AND ob.aa_number_01 = vju.id
            JOIN ( SELECT to_number(column_value) as app_id FROM TABLE(apex_string.split(p_app_ids, ':')) ) flt ON v_app.application_id = flt.app_id
        UNION ALL  --static application files (not included in app components view)
        SELECT 
            aasf.application_file_id as id,
            aasf.file_name as name,
            ot.object_type_id,
            v_app.application_id,
            vju.object_id,
            lower(ot.code) || '_' || aasf.application_id || '_' || aasf.application_file_id || '.sql' as filename
        FROM 
            apex_application_static_files aasf
            JOIN (SELECT to_number(column_value) as app_id FROM TABLE(apex_string.split('400', ':')) ) flt ON aasf.application_id = flt.app_id
            JOIN v_applications v_app ON aasf.application_id = v_app.application_number 
            CROSS JOIN (SELECT object_type_id, code FROM object_types WHERE code = 'STATIC_APP_FILE') ot
            LEFT JOIN 
            (
            SELECT 
                ob.object_id,
                ob.aa_number_01
            FROM 
                objects ob
                JOIN object_types ot ON ob.object_type_id = ot.object_type_id
            WHERE 
                ot.code = 'STATIC_APP_FILE'
            ) vju ON aasf.application_file_id = vju.aa_number_01 
    ) v
    ON (obj.object_id = v.object_id)
    WHEN NOT MATCHED THEN INSERT (object_type_id, name, filename, parent_object_id, aa_number_01) 
        VALUES (
            v.object_type_id, 
            v.name, 
            v.filename,
            v.application_id,
            v.id
            )
    WHEN MATCHED THEN UPDATE SET 
        obj.name = v.name,
        obj.filename = v.filename
    ;
    
    
    --mark missing componentes (presumably deleted from applications) as inactive
    UPDATE objects
    SET active_yn = 'N'
    WHERE object_id in 
        (
        SELECT 
            v_apc.app_component_id
        FROM 
            v_app_components v_apc
            JOIN (SELECT to_number(column_value) as app_id FROM TABLE(apex_string.split('400', ':')) ) flt ON v_apc.application_number = flt.app_id
        WHERE 
            v_apc.object_type_code <> 'STATIC_APP_FILE'
        AND v_apc.active_yn = 'Y'
        AND NOT EXISTS 
            (
            SELECT 1 
            FROM apex_appl_export_comps apex_comp
            WHERE 
                v_apc.app_component_number = apex_comp.id
            AND v_apc.application_number = apex_comp.application_id
            AND v_apc.object_type_code = apex_comp.type_name
            )
        )
    ;

END p_refresh_app_comp;


FUNCTION f_merge_app_component (
    p_comp_id number,
    p_app_id number,
    p_type_code varchar2,
    p_comp_name varchar2
) RETURN objects.object_id%TYPE IS

    CURSOR c_data IS
        SELECT
            ot.object_type_id,
            app.application_id as dome_app_id
        FROM
            object_types ot
            CROSS JOIN v_applications app 
        WHERE
            ot.code = p_type_code
        AND app.application_number = p_app_id
        ; 

    lrData c_data%ROWTYPE;

    lnObjectID objects.object_id%TYPE;

BEGIN
    --get app component ID
    BEGIN
        SELECT
            app_component_id
        INTO
            lnObjectID
        FROM 
            v_app_components
        WHERE
            application_number = p_app_id
        AND app_component_number = p_comp_id
        AND object_type_code = p_type_code
        ;
        
        --if component already exists in DOME register -> update name
        UPDATE objects 
        SET name = p_comp_name
        WHERE object_id = lnObjectID;
        
    EXCEPTION WHEN no_data_found THEN
        --if component doesn't exist in DOME register -> add component to register
        OPEN c_data;
        FETCH c_data INTO lrData;
        if c_data%NOTFOUND then
            RAISE_APPLICATION_ERROR(-20010, 'Object type with code ' || p_type_code || ' does not exist!');
        end if;
        CLOSE c_data;
        
    
        INSERT INTO objects (
            object_type_id, 
            name, 
            filename, 
            parent_object_id, 
            aa_number_01
        )
        VALUES (
            lrData.object_type_id,
            p_comp_name,
            lower(p_type_code) || '_' || p_app_id || '_' || p_comp_id || '.sql',
            lrData.dome_app_id,
            p_comp_id
        )
        RETURNING object_id INTO lnObjectID
        ;
    END;
    
    RETURN lnObjectID;
    
END f_merge_app_component;


FUNCTION f_create_db_object(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2
) RETURN objects.object_id%TYPE IS

    lrObject objects%ROWTYPE;

    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN
    --get object type and schema
    BEGIN
        SELECT object_type_id
        INTO lrObject.object_type_id 
        FROM object_types
        WHERE 
            code = p_type
        AND object_location = 'DB'
        ;
    EXCEPTION WHEN no_data_found THEN
        RAISE_APPLICATION_ERROR(-20001, 'Object type ' || p_type || ' is not found in register!');
    END;
    

    --If database object is not linked to database schema... no problem. Just don't assign object to schema.
     --Example is database directory.
    BEGIN
        SELECT schema_id
        INTO lrObject.parent_object_id
        FROM v_database_schemas
        WHERE schema_name = p_schema;
        
    EXCEPTION WHEN no_data_found THEN
        lrObject.parent_object_id := null;
    END;

    --name and filename
    lrObject.name := upper(p_name);
    lrObject.filename := pkg_objects.f_db_object_filename(
        p_name => p_name,
        p_type => p_type
    )
    ;
    
    lrObject.active_yn := 'Y';
    
    INSERT INTO objects 
    VALUES lrObject
    RETURNING object_id INTO lrObject.object_id
    ;

    COMMIT;

    RETURN lrObject.object_id;
END f_create_db_object;


FUNCTION f_exclude_from_record_yn(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2,
    p_exclusion_type varchar2  --P (patch) or R (register)
) RETURN varchar2 IS

    CURSOR c_exclude_pattern IS
        SELECT exclude_yes_no
        FROM 
            (
            SELECT
                'Y' as exclude_yes_no
            FROM 
                exclude_from_recording efr
                LEFT JOIN v_database_schemas v_dbs ON efr.db_schema_id = v_dbs.schema_id
                LEFT JOIN object_types ot ON efr.object_type_id = ot.object_type_id
            WHERE
                (efr.db_schema_id is null OR p_schema is null OR v_dbs.schema_name = p_schema)  --schema
            AND (efr.object_type_id is null OR ot.code = p_type)  --object
            AND 
                --naming pattern
                (
                    efr.like_or_regexp is null 
                OR  (efr.like_or_regexp = 'L' AND p_name like efr.naming_pattern)
                OR  (efr.like_or_regexp = 'R' AND regexp_like(p_name, efr.naming_pattern) )
                )
            AND
                --from patch or register
                (
                    (p_exclusion_type = 'R' AND efr.from_register_yn = 'Y')
                OR  (p_exclusion_type = 'P' AND efr.from_patch_yn = 'Y')
                )
            )
        WHERE 
            exclude_yes_no = 'Y'
        AND rownum = 1
        ;

    lrExclude c_exclude_pattern%ROWTYPE;

BEGIN
    --get data
    OPEN c_exclude_pattern;
    FETCH c_exclude_pattern INTO lrExclude;
    CLOSE c_exclude_pattern;
    
    --if no record fetched then do not exclude object
    lrExclude.exclude_yes_no := nvl( lrExclude.exclude_yes_no, 'N');
    
    
    RETURN lrExclude.exclude_yes_no;
    
END f_exclude_from_record_yn;



FUNCTION f_get_database_object_script(
    p_schema varchar2,
    p_name varchar2,
    p_type varchar2,
    p_grants_yn varchar2 default 'N'
) RETURN clob AS

    lcScript clob;

BEGIN
    EXECUTE IMMEDIATE 
        'BEGIN :script := ' || nvl(p_schema, pkg_objects.f_default_db_schema) || '.pkg_dome_utils.f_get_database_object_script(:name, :type, :grants_yn); END;' 
    USING 
        OUT lcScript,
        IN p_name, 
        IN p_type, 
        IN p_grants_yn
    ;
    
    RETURN lcScript;
END f_get_database_object_script;



FUNCTION f_get_app_component_script(
    p_app_no number,
    p_component_id number,
    p_type varchar2,
    p_multilang_yn varchar2 default 'N'
) RETURN clob AS

    lcShema v_database_schemas.schema_name%TYPE;
    lcComponentID varchar2(50);
    lcScript clob;
    lcScriptOneLang clob;

    lrFiles apex_t_export_files;
    
    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN
    --schema name, from which application component script will be requested
    SELECT schema_name
    INTO lcShema
    FROM v_applications
    WHERE application_number = p_app_no
    ;


    --get component script
    --loop through main app and translated apps 
    FOR app IN 
        c_export_apps (
            p_app_no => p_app_no, 
            p_multilang_yn => p_multilang_yn 
        ) 
    LOOP
    
        --component ID for translated app should have "dot" plus translated application ID  
        lcComponentID := 
            p_component_id || 
            CASE app.translated_app_yn WHEN 'Y' THEN '.' || app.app_id ELSE null END
        ;
    
        --if lcShema is not null then

            EXECUTE IMMEDIATE 
                'BEGIN :script := ' || lcShema || '.pkg_dome_utils.f_get_app_component_script(:app_no, :component_id, :type); END;' 
            USING 
                OUT lcScriptOneLang, 
                IN app.app_id, 
                IN lcComponentID, 
                IN p_type
            ;

        /*
        else

            lrFiles := apex_export.get_application(
                p_application_id => app.app_id,
                p_split => false,
                p_with_translations => true,
                p_with_comments => true,
                p_components => apex_t_varchar2( p_type || ':' || lcComponentID )
            );
        
            lcScriptOneLang := lrFiles(lrFiles.first).contents;
        end if;
        */
        
        lcScript := lcScript || lcScriptOneLang || chr(10) || chr(10);
        
    END LOOP;

    RETURN lcScript;
    
END f_get_app_component_script;



FUNCTION f_get_app_script(
    p_app_no number,
    p_multilang_yn varchar2 default 'N'
) RETURN clob AS

    lcShema v_database_schemas.schema_name%TYPE;
    lcScript clob;
    lcScriptOneLang clob;
    lrFiles apex_t_export_files;

    PRAGMA AUTONOMOUS_TRANSACTION;

BEGIN
    --schema name, from which application component script will be requested
    SELECT schema_name
    INTO lcShema
    FROM v_applications
    WHERE application_number = p_app_no
    ;

    FOR app IN 
        c_export_apps (
            p_app_no => p_app_no, 
            p_multilang_yn => p_multilang_yn 
        ) 
    LOOP

    --get component script
    --if lcShema is not null then

        EXECUTE IMMEDIATE 
            'BEGIN :script := ' || lcShema || '.pkg_dome_utils.f_get_app_script(:app_no); END;' 
        USING 
            OUT lcScriptOneLang,
            IN app.app_id
        ;

    /*
    else

        lrFiles := apex_export.get_application(
            p_application_id => p_app_no,
            p_split => false,
            --p_with_ir_public_reports => true,
            p_with_translations => true,
            p_with_comments => true
        );
    
        lcScript := lrFiles(lrFiles.first).contents;
    end if;
    */

        lcScript := lcScript || lcScriptOneLang || chr(10) || chr(10);
        
    END LOOP;

    RETURN lcScript;
    
END f_get_app_script;



FUNCTION f_source_filename(
    p_object_id objects.object_id%TYPE
) RETURN varchar2 IS

    lrData pkg_objects.c_data%ROWTYPE;
    lcFilename varchar2(1000);
    
BEGIN
    --get data
    OPEN pkg_objects.c_data(p_object_id);
    FETCH pkg_objects.c_data INTO lrData;
    CLOSE pkg_objects.c_data;
    
    lcFilename := replace(lrData.source_folder, '#SCHEMA#', lower( nvl(lrData.db_schema, pkg_objects.f_default_db_schema) ) );
    lcFilename := replace(lcFilename, '#APP_ID#', lower(lrData.application_number) );
    
    lcFilename := lcFilename || '/' || lrData.filename;
    
    RETURN lcFilename;
        
END f_source_filename;



FUNCTION f_is_object_locked_yn(
    p_object_id objects.object_id%TYPE,
    p_user_id app_users.app_user_id%TYPE
) RETURN varchar2 IS
BEGIN
    RETURN CASE WHEN f_get_object_record(p_object_id).lock_type = 'E' THEN 'Y' ELSE 'N' END;
END f_is_object_locked_yn;


FUNCTION f_who_locked_object(
    p_object_id objects.object_id%TYPE
) RETURN app_users.app_user_id%TYPE IS
BEGIN
    RETURN f_get_object_record(p_object_id).lock_app_user_id;
END f_who_locked_object;


PROCEDURE p_lock_object(
    p_object_id objects.object_id%TYPE,
    p_lock_type objects.lock_type%TYPE,
    p_comment objects.lock_comment%TYPE
) IS
BEGIN
    UPDATE objects
    SET
        lock_type = p_lock_type, 
        lock_app_user_id = nv('APP_LOGGED_USER_ID'),
        lock_date = sysdate, 
        lock_comment = p_comment
    WHERE object_id = p_object_id;

END p_lock_object;


PROCEDURE p_unlock_object(
    p_object_id objects.object_id%TYPE
) IS
BEGIN
    UPDATE objects
    SET
        lock_type = null, 
        lock_app_user_id = null,
        lock_date = null, 
        lock_comment = null
    WHERE object_id = p_object_id;

END p_unlock_object;


FUNCTION f_page_locked_in_apex_yn(
    p_object_id objects.object_id%TYPE
) RETURN varchar2 IS

    lrRecord v_app_components%ROWTYPE;
    lcYesNo varchar2(1);

BEGIN
    --schema name, from which application component script will be requested
    SELECT *
    INTO lrRecord
    FROM v_app_components
    WHERE app_component_id = p_object_id
    ;

    --get component script
    if lrRecord.app_schema_name is not null then

        EXECUTE IMMEDIATE 
            'SELECT ' || lrRecord.app_schema_name || '.pkg_dome_utils.f_page_locked_yn(:1, :2) FROM dual' 
        INTO lcYesNo
        USING lrRecord.application_number, lrRecord.app_component_number;

    else

        SELECT
            CASE 
                WHEN EXISTS 
                    (
                    SELECT 1 
                    FROM apex_application_locked_pages ap
                    WHERE
                        ap.application_id = lrRecord.application_number
                    AND ap.page_id = lrRecord.app_component_number
                    )
                THEN 'Y'
                ELSE 'N'
            END
        INTO lcYesNo
        FROM dual;

    end if;

    RETURN lcYesNo;

END f_page_locked_in_apex_yn;


FUNCTION f_default_db_schema 
RETURN v_database_schemas.schema_name%TYPE IS
BEGIN
    --TODO: make a parameter
    RETURN 'MBA';
END f_default_db_schema;



FUNCTION f_multilang_app_yn (
    p_application_id number
) RETURN varchar2 IS

    lcYesNo varchar2(1);

BEGIN
    SELECT
        CASE 
            WHEN EXISTS (
                SELECT 1 
                FROM apex_application_trans_map 
                WHERE primary_application_id = p_application_id
            ) THEN 'Y'
            ELSE 'N'
        END
    INTO lcYesNo
    FROM dual;
    
    RETURN lcYesNo;
END f_multilang_app_yn;

END PKG_OBJECTS;
/


--
-- PKG_UTILS  (Package Body) 
--
CREATE OR REPLACE PACKAGE BODY PKG_UTILS AS 

FUNCTION f_clob_to_blob(
    c clob,
    plEncoding IN NUMBER default 0) RETURN blob IS

    v_blob Blob;
    v_in Pls_Integer := 1;
    v_out Pls_Integer := 1;
    v_lang Pls_Integer := 0;
    v_warning Pls_Integer := 0;
    v_id number(10);

BEGIN
    if c is null then
        return null;
    end if;

    v_in:=1;
    v_out:=1;
    dbms_lob.createtemporary(v_blob,TRUE);
    
    DBMS_LOB.convertToBlob(
        v_blob,
        c,
        DBMS_lob.getlength(c),
        v_in,
        v_out,
        plEncoding,
        v_lang,
        v_warning
    );

    RETURN v_blob;

END f_clob_to_blob; 


FUNCTION f_blob_to_clob(
    blob_in IN blob,
    plEncoding IN NUMBER default 0) RETURN clob IS

    v_clob Clob;
    v_in Pls_Integer := 1;
    v_out Pls_Integer := 1;
    v_lang Pls_Integer := 0;
    v_warning Pls_Integer := 0;
    v_id number(10);

BEGIN
    if blob_in is null then
        return null;
    end if;

    v_in:=1;
    v_out:=1;
    dbms_lob.createtemporary(v_clob,TRUE);
    DBMS_LOB.convertToClob(v_clob,
                           blob_in,
                           DBMS_lob.getlength(blob_in),
                           v_in,
                           v_out,
                           plEncoding,
                           v_lang,
                           v_warning);

    RETURN v_clob;

END f_blob_to_clob;

PROCEDURE p_download_document(
    p_doc IN OUT blob,
    p_file_name varchar2,
    p_disposition varchar2 default 'attachment'  --values "attachment" and "inline"
    ) IS
BEGIN
    htp.init;
    OWA_UTIL.MIME_HEADER('application/pdf', FALSE);
    htp.p('Content-length: ' || dbms_lob.getlength(p_doc) ); 
    htp.p('Content-Disposition: ' || p_disposition || '; filename="' || p_file_name || '"' );
    OWA_UTIL.HTTP_HEADER_CLOSE;
    
    WPG_DOCLOAD.DOWNLOAD_FILE(p_doc);
    DBMS_LOB.FREETEMPORARY(p_doc);
    
    apex_application.stop_apex_engine;
END p_download_document;  


PROCEDURE p_download_document(
    p_text IN OUT clob,
    p_file_name varchar2,
    p_disposition varchar2 default 'attachment'  --values "attachment" and "inline"
    ) IS
    
    lbBlob blob;
    
BEGIN
    lbBlob := f_clob_to_blob(p_text);
    
    p_download_document(
        p_doc => lbBlob,
        p_file_name => p_file_name,
        p_disposition => p_disposition
    );
END p_download_document;


PROCEDURE p_vc_arr2_to_apex_coll(
    p_app_coll wwv_flow_global.vc_arr2,
    p_apex_coll_name varchar2,
    p_n001_yn varchar2 default 'N'
) IS
BEGIN
    APEX_COLLECTION.create_or_truncate_collection(p_apex_coll_name);

    FOR t IN 1 .. p_app_coll.count LOOP
        APEX_COLLECTION.add_member(
            p_collection_name => p_apex_coll_name,
            p_c001 => p_app_coll(t),
            p_n001 => CASE WHEN p_n001_yn = 'Y' THEN to_number(p_app_coll(t)) ELSE null END
        );
    END LOOP;

END p_vc_arr2_to_apex_coll;


PROCEDURE p_seed_and_publish (
    p_app_no number,
    p_seed_yn varchar2 default 'Y',
    p_publish_yn varchar2 default 'Y',
    p_commit_yn varchar2 default 'N'
) IS

    CURSOR c_languages IS
        SELECT
            translated_app_language as lang
        FROM
            apex_application_trans_map
        WHERE
            primary_application_id = p_app_no
        ;
    
BEGIN
    FOR t IN c_languages LOOP
    
        if p_seed_yn = 'Y' then
            apex_lang.seed_translations(
                p_application_id => p_app_no,
                p_language => t.lang
            );
        end if;
        
        if p_publish_yn = 'Y' then
            apex_lang.publish_application(
                p_application_id => p_app_no,
                p_language => t.lang
            );
        end if;
        
    END LOOP;

    if p_commit_yn = 'Y' then
        COMMIT;
    end if;
    
END p_seed_and_publish;

END PKG_UTILS;
/



CREATE OR REPLACE PACKAGE BODY pkg_auth AS
/******************************************************************************
   NAME:       pck_auth
   PURPOSE:

   REVISIONS:
   Ver        Date        Author           Description
   ---------  ----------  ---------------  ------------------------------------
   1.0        22.06.2018      ticaz       1. Created this package body.
******************************************************************************/

lrKey raw(32) := UTL_RAW.CAST_TO_RAW('A1A2A3A4A5A6CAFE');


FUNCTION encrypt_password(p_password in varchar2) RETURN raw IS
    lbBlob blob;
BEGIN
    RETURN DBMS_CRYPTO.encrypt(UTL_RAW.CAST_TO_RAW(p_password), 4353, lrKey);
END;


FUNCTION decrypt_password(p_username in varchar2) RETURN varchar2 IS

    lrPwd raw(500);

BEGIN
    SELECT DBMS_CRYPTO.decrypt(login_password, 4353, lrKey)
    INTO lrPwd
    FROM app_users
    WHERE upper(login_username) = upper(p_username);

    RETURN UTL_RAW.cast_to_varchar2(lrPwd);
END;


FUNCTION f_login(
    p_username in varchar2,
    p_password in varchar2) RETURN boolean IS

    lcPwd varchar2(1000);

BEGIN
    if decrypt_password(p_username) <> p_password then
        RETURN false;
    end if;

    RETURN true;

EXCEPTION WHEN NO_DATA_FOUND THEN
    RETURN false;
END;


PROCEDURE post_auth(
    p_username in varchar2,
    out_user_id out number,
    out_user_display_name out varchar2) IS
BEGIN
    SELECT 
        app_user_id, 
        display_name
    INTO 
        out_user_id, 
        out_user_display_name
    FROM app_users
    WHERE upper(login_username) = upper(p_username);

END post_auth;


PROCEDURE post_auth_db_account(
    p_username in varchar2,
    out_user_id out number,
    out_user_display_name out varchar2) IS
BEGIN
    SELECT 
        app_user_id, 
        display_name
    INTO 
        out_user_id, 
        out_user_display_name
    FROM app_users
    WHERE upper(proxy_user) = upper(p_username);

END post_auth_db_account;


PROCEDURE p_change_pwd(
    p_username varchar2,
    p_new_password varchar2) IS
BEGIN
    UPDATE app_users
    SET login_password = encrypt_password(p_new_password)
    WHERE upper(login_username) = upper(p_username);

    COMMIT;
END;



END pkg_auth;
/

