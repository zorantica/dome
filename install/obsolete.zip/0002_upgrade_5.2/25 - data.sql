SET DEFINE OFF;
Insert into R_SETTINGS
   (SETTING_ID, CODE, NAME, HIDDEN_YN)
 Values
   (8, 'EXPORT_MULTILANG_YN', 'Export APEX applications and components as multi language? Values are Y/N', 'N');
Insert into R_SETTINGS
   (SETTING_ID, CODE, NAME, HIDDEN_YN)
 Values
   (9, 'SEED_PUBLISH_YN', 'Seed and publish miltilang apps before patch confirmation? Values are Y/N', 'N');


INSERT INTO project_settings (project_id, setting_id, value_vc2)
SELECT
    p.project_id,
    v.setting_id,
    'N' as value_no
FROM 
    projects p
    CROSS JOIN (SELECT setting_id FROM r_settings WHERE setting_id in (8,9) ) v
;

COMMIT;


SET DEFINE OFF;
Insert into DOME_SETTINGS
   (CODE, VALUE_NUM)
 Values
   ('VERSION', 1000000);
COMMIT;


