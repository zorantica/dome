SET DEFINE OFF;
--
-- V_PATCH_OBJ_SRC_SCRIPTS  (View) 
--
CREATE OR REPLACE FORCE VIEW V_PATCH_OBJ_SRC_SCRIPTS
AS 
SELECT  --database objects
    po.patch_object_id,
    po.patch_id,
    PKG_OBJECTS.f_get_database_object_script(
        p_schema => v_do.db_schema_name, 
        p_name => v_do.db_object_name, 
        p_type => v_do.object_type_code
    ) as object_script,
    pkg_objects.f_source_filename(po.object_id) as source_filename,
    PKG_PATCH_OBJECTS.f_next_version(po.object_id) as next_version
FROM 
    patch_objects po
    JOIN v_database_objects v_do ON po.object_id = v_do.db_object_id
UNION ALL  --application components
SELECT
    po.patch_object_id,
    po.patch_id,
    PKG_OBJECTS.f_get_app_component_script(
        p_app_no => v_ac.application_number, 
        p_component_id => v_ac.app_component_number, 
        p_type => v_ac.object_type_code,
        p_multilang_yn => v_p.export_mutilang_yn
    ) as object_script,
    pkg_objects.f_source_filename(po.object_id) as source_filename,
    PKG_PATCH_OBJECTS.f_next_version(po.object_id) as next_version
FROM 
    patch_objects po
    JOIN v_app_components v_ac ON po.object_id = v_ac.app_component_id
    JOIN v_patches v_p ON po.patch_id = v_p.patch_id
UNION ALL  --applications
SELECT
    po.patch_object_id,
    po.patch_id,
    PKG_OBJECTS.f_get_app_script(
        p_app_no => v_app.application_number,
        p_multilang_yn => v_p.export_mutilang_yn
    ) as object_script,
    pkg_objects.f_source_filename(po.object_id) as source_filename,
    PKG_PATCH_OBJECTS.f_next_version(po.object_id) as next_version
FROM 
    patch_objects po
    JOIN v_applications v_app ON po.object_id = v_app.application_id
    JOIN v_patches v_p ON po.patch_id = v_p.patch_id
/


CREATE OR REPLACE FORCE VIEW V_PATCHES
AS 
SELECT
    pa.patch_id,
    pa.release_id,
    pa.task_id,
    pr.project_id,
    pa.created_app_user_id,
    pa.owner_app_user_id,
    pa.patch_number,
    pa.automatic_yn,
    pa.created_on,
    pa.confirmed_app_user_id,
    pa.confirmed_on,
    pa.user_comments,
    pa.release_notes,
    ta.code || '_' || pa.patch_number as patch_code,
    ta.code as task_code,
    ta.code || ' - ' || ta.name as task_code_and_name,
    ta.name as task_name,
    ta.code || '_' || pa.patch_number || ' (' || ta.name || ')' as display,
    tg.code || ' - ' || tg.name as task_group_name,
    rls.code as release_code,
    pa.release_order,
    pr.name as project_name,
    usr_cr.display_name as user_created,
    usr_con.display_name as user_confirmed,
    (CASE WHEN pa.confirmed_app_user_id is null THEN 'N' ELSE 'Y' END) as confirmed_yn,
    (CASE WHEN EXISTS 
       (SELECT 1 
        FROM 
            patch_installs pi
            JOIN environments env ON pi.environment_id = env.environment_id
        WHERE 
            pi.patch_id = pa.patch_id
        AND pi.end_date is not null
        AND env.production_yn = 'Y')
        THEN 'Y' ELSE 'N' END) as installed_on_prod_yn,
    (SELECT
        listagg(au.display_name, ', ') within group (order by au.display_name) as user_name
    FROM 
        user_works_on_patch uwop
        JOIN app_users au ON uwop.app_user_id = au.app_user_id
    WHERE 
        uwop.patch_id = pa.patch_id
    AND uwop.stop is null) as currently_works_on_patch,
    ta.finished_yn as task_finished_yn,
    patch_temp.patch_template_id,
    patch_temp.code as patch_template_code,
    pa.for_production_yn,
    ta.external_link,
    usr_ow.display_name as user_owner,
    pa.for_production_comment,
    tg.hidden_yn as task_group_hidden_yn,
    regexp_replace(
        replace( substr(ta.code || '_' || pa.patch_number || ' - ' || ta.name, 1, 100), '"', null),
        '[/\:*?<>]',
        '_'
    ) as filename_without_extension,
    pkg_settings.f_project_sett_vc2(pr.project_id, 'EXPORT_MULTILANG_YN') as export_mutilang_yn,
    pkg_settings.f_project_sett_vc2(pr.project_id, 'SEED_PUBLISH_YN') as seed_and_publish_yn
FROM
    patches pa
    JOIN tasks ta ON pa.task_id = ta.task_id
        JOIN task_groups tg ON ta.task_group_id = tg.task_group_id
            JOIN projects pr ON tg.project_id = pr.project_id
    JOIN app_users usr_cr ON pa.created_app_user_id = usr_cr.app_user_id
    JOIN app_users usr_ow ON pa.owner_app_user_id = usr_ow.app_user_id
    LEFT JOIN app_users usr_con ON pa.confirmed_app_user_id = usr_con.app_user_id
    LEFT JOIN releases rls ON pa.release_id = rls.release_id
    LEFT JOIN patch_templates patch_temp ON patch_temp.code = pkg_settings.f_project_sett_vc2(pr.project_id, 'PATCH_TEMPLATE_CODE')
/